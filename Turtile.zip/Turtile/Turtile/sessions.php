<?php
class session
    {
    function set($sessionname,$values)
        {
            $_SESSION["$sessionname"] = $values;
        }
    function get($sessionname)
        {
            return $_SESSION["$sessionname"];
        }
     function sessionunset($sessionname)
         {
            unset($_SESSION["$sessionname"]);
         }
     function destroy()
         {
            session_destroy();
         }
    }
?>