<?php
/*
  ####################################################################################################
  #       Turtile is a php framework created by Sibin Thomas(php Developer)                          #
  #       Turtile can be use as a micro frame work for making rest apis etc..                        #
  #       email:sibinthomasmdkm@gmail.com                                                            #
  ####################################################################################################
*/
 function baseurl()
                    {
                    $actual_link = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
                    $directory=getcwd();
                    $directory=explode('/',$directory);
                    $directory_count=count($directory);
                    $directory=$directory[$directory_count-1];
                    $passurl=explode($directory,$actual_link);
                    $passurl=$passurl[0];
                    return $baseurl=$passurl.$directory;
                    }
require_once"config/pageconfig.php";
class configpages extends defaultpages
{

}
class view
{
	function page($page_with_path,$data)
	{
		$page_with_path='application/view/'.$page_with_path;
        	if(file_exists($page_with_path))
        		{
                    require($page_with_path);
			    }
                else
                {
                    echo "<br>";
                    echo "<div style='border-style:solid; border-width: 2px;'><center><h2 style='color:green'><u>Turtile</u></h2></center><center>";
                    echo "Requested template   ".$page_with_path." not found<br><br></div>";
		            echo "</center></div>";
                }
      }
}
$defultpageobject=new configpages;
$config_pages=$defultpageobject->PageSettings();
$currentdirectory= getcwd();
$root=explode("/",$currentdirectory);
$count_last_folder=count($root);
$lastfolder=$root[$count_last_folder-1];
$url = rawurldecode($_SERVER['REQUEST_URI']);
$url=explode("$lastfolder",$url);
$urlstring=$url[1];
$validurl=explode("/",$urlstring);
$valid_index=end($validurl);
$flag=0;
$indexfinder=explode('index.php',$valid_index);
$clay=$indexfinder[0];
if($clay=='')
{
$flag=1;
}
$urlvalid_count=count($validurl);
if($urlvalid_count<3 && $config_pages['index']!='')
    {

        $indexpath=$config_pages['index'];
        $indexpath=explode('/',$indexpath);
        $it = new RecursiveTreeIterator(new RecursiveDirectoryIterator("application/controller", RecursiveDirectoryIterator::SKIP_DOTS));
        foreach($it as $path)
            {
                $class=$indexpath[0];
                $function=$indexpath[1];
                $path=substr($path, 2);
                $path=str_replace("\-","",$path);
                $path=str_replace("|-","",$path);
                $path = str_replace(' ', '',$path);
                    if(strpos($path, $class) !== false)
                        {
                            $extension = substr($path, -4);
                            if($extension=='.php')
                                {
                                   if($valid_index !='' && $flag==0)
                                   {
                                        echo "<div style='border-style:solid; border-width: 2px;'><center><h2 style='color:green'><u>Turtile</u></h2></center><center>";
                                        echo "<p><b><font color='red'>Warning:</font><b></b>Index page cant accept parameter via url</b></p>";
                                        echo "<p><i>If you need the parameter you can use like this 'rootfolder/index.php?parameter name=value'</i></p>";
                                        echo "<p><b>Eg:index.php?data=$valid_index</b></p>";
                                        echo "<br>";
                                        echo "</center></div>";
                                    }
                                   require($path);
                                }
                        }
            }
        $page_obj=new $class;
        $data='';
        $page_obj->$function($data);
    }
else if($urlvalid_count<3 && $config_pages['index']=='')
    {
        echo '
        <style>
        #overlay
            {
                position: fixed;
                display: none;
                width: 100%;
                height: 100%;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background-color: white;
                z-index: 2;
                cursor: pointer;
            }
        </style>
            <div id="overlay" onclick="off()">
                <center>
                    <div style="background-color: white;margin-top:50px;border-style: solid;
                    border-width: 2px;" id="text"><h2 style="color:green"><u>Turtile</u><h2><p size="3"><font>The url is invalid</font></p><p><i>please enter in the below order</i></p><p>Rootfolder/ControllerClass/ControllerFunction</p></div>
                </center>
            </div>
            <div style="padding:20px">
            </div>
        <script>
            function on()
                {
                    document.getElementById("overlay").style.display = "block";
                }
             on();
        </script>
        ';
    }
    else
        {
            $url=$url[1];
            $slice=explode("/",$url);
            $count=count($slice);
            $countofdata=$count-2;
            $variables='';
    for($i=3;$i<=$countofdata+1;$i++)
        {
	        $variable=$slice[$i];
	        $variables.=$variable;
	        if($i < $countofdata+1)
            {
                $variables.="___";
            }
        }
        $class=$slice[1];
        $function=$slice[2];//current function*/
        $variables=explode("___",$variables);
        $variables=(array_filter($variables, 'strlen'));
        $fnexist=(int)method_exists($class,$function);
        if($fnexist==1)
            {
                $catcher=new $class;
                $catcher->$function($variables);
            }
        else
        {
             if($urlvalid_count >2)
                {
                    if($config_pages['404']=='')
                        {
                            echo "<div style='border-style:solid; border-width: 2px;'><center><h2 style='color:green'><u>Turtile</u></h2></center><center>";
                            echo "<p>function    <b>".$function."</b>  is not found in <b>".$class."</b> or <b>".$class."</b> class is not found</p><p style='color:red'><i>you can add 404 page not found instead of this error for 404 page add the page controller to page config</i></p>";
                            echo "</center></div>";
                        }
            else
                {
                    $cur_dir = getcwd();
                    $cur_dir=explode("/",$cur_dir);
                    $count=count($cur_dir);
                    $cur_dir=$cur_dir[$count-1];
                    $notfount=$config_pages['404'];
                    header("Location:/$cur_dir/$notfount");
                    die();
                }
                }
        }
}
?>