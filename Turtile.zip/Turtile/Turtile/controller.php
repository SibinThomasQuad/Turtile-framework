<?php
$it = new RecursiveTreeIterator(new RecursiveDirectoryIterator("application/model", RecursiveDirectoryIterator::SKIP_DOTS));
foreach($it as $path) {
  $path=substr($path, 2);
  require_once($path);
}
class stripSymbols
{
 	function filter($value)
		{
		  $value = preg_replace("/[^a-zA-Z]/", "", $value);
		  return $value;
		}
}
?>
