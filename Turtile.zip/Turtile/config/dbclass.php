<?php
require_once( 'dbconfig.php' );
class DB_Functions extends DatabaseSettings
{
    public function __construct()
    {
    $settings = DatabaseSettings::getSettings();
		// Get the main settings from the array we just loaded
		$host = $settings['dbhost'];
		$name = $settings['dbname'];
		$user = $settings['dbusername'];
		$pass = $settings['dbpassword'];
        $conn = new mysqli($host,$user,$pass,$name);
        $this->connection=$conn;

    }
	//Execute the query
    public function query($query)
	{
         $conn=$this->connection;
            if ($conn->connect_error)
	        {
               echo "<center><div style='border-style:solid; border-width: 2px;'><center><h2 style='color:green'><u>Turtile</u></h2></center><center>";
               echo "<center><h5>SQL ERROR</h5></center>";
               echo "<font size='2'><i>Error description</i>:<p style='color:red'>Check the username password and host is valid or not</p></font>";
               die("Connection failed: " . $conn->connect_error);
               echo "</center></div>";
	        }
            if (!mysqli_query($conn,$query))
            {
                echo "<div style='border-style:solid; border-width: 2px;'><center><h2 style='color:green'><u>Turtile</u></h2></center><center>";
                echo "<center><h5>SQL ERROR</h5></center>";
                echo "<font size='2'><i>Error description</i>:<p> " . mysqli_error($conn)."</p></font>";
                echo "</center></div>";
            }
            else
                {
        	        return $result = $conn->query($query);
                }

        }
        //Feth Data as arry Number
        public function fetchArray($result)
	    {
           if($result!='')
            {
      	        $row=mysqli_fetch_array($result,MYSQLI_NUM);
	            return $row;
            }
        }
        //Feth Data as arry Asosiative
	public function fetchAsos($result)
	    {
            if($result!='')
            {
        	    $row=mysqli_fetch_array($result,MYSQLI_ASSOC);
		        return $row;
            }
        }
	    //Fetch the row count
        public function rowcount($result)
	        {
                if($result!='')
                    {
		                $rowcount=mysqli_num_rows($result);
		                return $rowcount;
                    }
            }
        public function bindparam_single_raw($query,$type,$params)
            {
            $connection=$this->connection;
            $statement = $connection->prepare($query);
            call_user_func_array(array($statement, "bind_param"), array_merge(array($type), $params));
            $statement->execute();
            $result = $statement->get_result();
            $get_data = $result->fetch_array(MYSQLI_ASSOC);
            $result->close();
            $statement->close();
            return  $get_data;
            }
           public function bindparam_multiple_raw($query,$type,$params)
            {
            $connection=$this->connection;
            $statement = $connection->prepare($query);
            call_user_func_array(array($statement, "bind_param"), array_merge(array($type), $params));
            $statement->execute();
            $result = $statement->get_result();
            $get_data = $result->fetch_all(MYSQLI_ASSOC);
            $result->close();
            $statement->close();
            return  $get_data;
            }
           public function bindparam_raw_count($query,$type,$params)
            {
            $connection=$this->connection;
            $statement = $connection->prepare($query);
            call_user_func_array(array($statement, "bind_param"), array_merge(array($type), $params));
            $statement->execute();
            $row = $statement->fetch();
            $statement->close();
            return  $row;
            }
}
?>
