<?php
class defaultpages
{
	var $pages;

	function PageSettings()
	{
		$pages['index'] = 'myfiles/sibin';
        $pages['404'] = 'myfiles/notfount';
		return $pages;
	}
}
?>
