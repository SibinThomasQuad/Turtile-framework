<?php
session_start();
require('Turtile/sessions.php');
$functionblocker=0;
require_once"config/pageconfig.php";
class configpages_index extends defaultpages
    {

    }
$defultpageobject_indexpage=new configpages_index;
$config_pages_indexpage=$defultpageobject_indexpage->PageSettings();
//url checker
$currentdirectory= getcwd();
$root=explode("/",$currentdirectory);
$count_last_folder=count($root);
$lastfolder=$root[$count_last_folder-1];
$url = rawurldecode($_SERVER['REQUEST_URI']);
$url=explode("$lastfolder",$url);
$urlstring=$url[1];
$validurl=explode("/",$urlstring);
    $urlvalid_count=count($validurl);
    if($urlvalid_count<3 && $config_pages_indexpage['index']!='')
        {
            $functionblocker=1;
        }
//urlchecker
//fetch class from url
    if($functionblocker==0)
        {
            $currentdirectory= getcwd();
            $root=explode("/",$currentdirectory);
            $count_last_folder=count($root);
            $lastfolder=$root[$count_last_folder-1];
            $url = rawurldecode($_SERVER['REQUEST_URI']);
            $url=explode("$lastfolder",$url);
            $url=$url[1];
            $slice=explode("/",$url);
            $count=count($slice);
            $countofdata=$count-2;
            $variables='';
        for($i=3;$i<=$countofdata+1;$i++)
            {
	            $variable=$slice[$i];
	            $variables.=$variable;
	            if($i < $countofdata+1)
                    {
                        $variables.="___";
                    }
            }
$class=$slice[1];
$function=$slice[2];
$it = new RecursiveTreeIterator(new RecursiveDirectoryIterator("application/controller", RecursiveDirectoryIterator::SKIP_DOTS));
    foreach($it as $path)
        {
            $path=substr($path, 2);
            $path=str_replace("\-","",$path);
            $path=str_replace("|-","",$path);
            $path = str_replace(' ', '',$path);
        if(strpos($path, $class) !== false)
            {
                $extension = substr($path, -4);
            if($extension=='.php')
                {
                    require($path);
                }
            }
        }
       }
require('Turtile/controller.php');
require('Turtile/model.php');
require('Turtile/router.php');
?>