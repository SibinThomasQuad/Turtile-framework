<html>
<body>
<?php
echo $data;
?>
<h1>Registration form</h1>
</body>
</html>
