<html>
<body>
<?php
echo $data;
$obj=new view;
?>
<h1>Welcome please login</h1>
 <form method='POST' action='<?php echo baseurl();?>/bibin/namer/logged'>
 <input type='text' value='' name='sibin'/>
 <input type='submit' value='save'>
 </form>
 </body>
</html>
<?php
$data='sibin thomas';
$obj->page('view.php',$data);
?>
