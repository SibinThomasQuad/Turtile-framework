<?php
class myfiles
{
    public function __construct()
        {
            $prevent_sqli=new stripSymbols;//this object for filter symbols
            $obj=new view;//this object for call view pages
            $db=new DBO;//this for data base function
            $this->SQLINJECTION=$prevent_sqli;
            $this->VIEW=$obj;
            $this->db=$db;
        }
function sibin($response)
	{

        $prevent_sqli=$this->SQLINJECTION;//filter the variable from sql injection
		$obj=$this->VIEW;//this is the object that call the function to view page
		$db=$this->db;//this call the function for db operation
		/*
        $response is the variable that contain the parameter passing via url 
		$response is an array
        */
        print_r($response);
		$query='select * from OfficeMaster';
        $name='sibin---{}{}{}{}{}......';
		$name=$prevent_sqli->filter($name);
		$count=$db->execute($query);
		$data=$count;
        $file=$db->binparam();
        echo "result from bind parameter<br>";
        print_r($file);
        $sessionobj=new session;
        $sessionobj->set('name','sibin');
		$obj->page('login.php',$data);//data is passing to login.php in template
        echo  "The session data is ".$sessionobj->get('name');
	}
public function namer($pass)
{
    echo $name=$_POST['sibin'];

    //print_r($pass);
}
public function notfount($response)
{
    echo "page not fount";
}
}
?>
