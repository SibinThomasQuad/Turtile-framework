<?php
class bibin
{
    public function __construct()
        {
            $prevent_sqli=new stripSymbols;
            $obj=new view;
            $db=new DBO;
            $this->SQLINJECTION=$prevent_sqli;
            $this->VIEW=$obj;
            $this->db=$db;
        }
public function namer($variables)
{
    print_r($variables);
    echo "Working";
}
}
?>
