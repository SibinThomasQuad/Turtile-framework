<?php
class DBO
{

  function execute($query)
	{
        $db=new DB_Functions;
	    $result=$db->query($query);//executing a query
        $data=$db->rowcount($result);
	    return $data;
	}
   function binparam()
       {
        $db=new DB_Functions;
        $query="select * from OfficeMaster where OfficeCode=?";
        $value='0100701';
        $paramer=array(&$value);
	$result=$db->bindparam_raw_count($query,'s',$paramer);
        $data=$result;
	return $data;
       }
}
?>

